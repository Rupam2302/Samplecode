﻿namespace CommonAPI.EFCore
{
	public class ScratchCard
	{
		public Guid Id { get; set; }
		public double Discountamount { get; set; }
		public DateTime Expirydate { get; set; }
		public bool IsScratched { get; set; }
		public bool Isactive { get; set; }
	}
}
