﻿using System.ComponentModel.DataAnnotations.Schema;
namespace CommonAPI.EFCore
{
	public class Transaction
	{
		public Guid Id { get; set; }
		public DateTime DateOftransaction { get; set; }
		public double Transactionamount { get; set; }

		[ForeignKey("User")]
		public Guid Userid { get; set; }
		public User User { get; set; }

		[ForeignKey("ScratchCard")]
		public Guid ScratchCardid { get; set; }

		public ScratchCard ScratchCard { get; set; }
	}
}
