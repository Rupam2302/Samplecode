﻿using Microsoft.EntityFrameworkCore;
namespace CommonAPI.EFCore
{
	public class MyDBContext : DbContext
	{
		public MyDBContext(DbContextOptions options) : base(options)
		{
		}

		public DbSet<User> User { get; set; }
		public DbSet<ScratchCard> ScratchCard { get; set; }
		public DbSet<Transaction> Transaction { get; set; }
	}
}
