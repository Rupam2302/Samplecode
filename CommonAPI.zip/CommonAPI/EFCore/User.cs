﻿namespace CommonAPI.EFCore
{
	public class User
	{
		public Guid Id { get; set; }
		public string Firstname { get; set; }
		public string Lastname { get; set; }
		public string Useremail { get; set; }
		public bool Isactive { get; set; }
	}
}
