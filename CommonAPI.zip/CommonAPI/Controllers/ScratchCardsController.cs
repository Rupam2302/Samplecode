﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CommonAPI.EFCore;
using Microsoft.DotNet.Scaffolding.Shared.Messaging;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CommonAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScratchCardsController : ControllerBase
    {
        private readonly MyDBContext _context;

        public ScratchCardsController(MyDBContext context)
        {
            _context = context;
        }

        // GET: api/ScratchCards
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ScratchCard>>> GetScratchCard()
        {
            return await _context.ScratchCard.ToListAsync();
        }

		// GET: api/ScratchCards/5
		[HttpGet("{id}")]
        public async Task<ActionResult<ScratchCard>> GetScratchCard(Guid id)
        {
            var scratchCard = await _context.ScratchCard.FindAsync(id);

            if (scratchCard == null)
            {
                return NotFound();
            }

            return scratchCard;
        }

        // PUT: api/ScratchCards/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutScratchCard(Guid id, ScratchCard scratchCard)
        {
            if (id != scratchCard.Id)
            {
                return BadRequest();
            }

            _context.Entry(scratchCard).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ScratchCardExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ScratchCards
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ScratchCard>> PostScratchCard(ScratchCard scratchCard)
        {
            _context.ScratchCard.Add(scratchCard);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetScratchCard", new { id = scratchCard.Id }, scratchCard);
        }

        [HttpPost("{NumberOfScratchCard}")]
        public async Task<ActionResult> PostScratchCardByNumber(int NumberOfScratchCard)
        {
            try
            {
                ScratchCard scratchCard = new ScratchCard();
				var existingScratchcardList = _context.ScratchCard.ToList().Where(x => x.IsScratched == false);
                var existingScratchcardCount = existingScratchcardList.Count();
                if (existingScratchcardCount >= NumberOfScratchCard)
                {
                    return Content("Number Of UnUsedScarcthCard are Still Exists");
                }
                else
                {
                    for (int i = 0; i <= NumberOfScratchCard; i++)
                    {
                        Random randomnumber = new Random();
                        ScratchCard scratchCard2 = new ScratchCard();
                        scratchCard2.Discountamount = randomnumber.Next(1, 1000);
                        scratchCard2.Expirydate = DateTime.Now.AddDays(5);
                        scratchCard2.Isactive = true;
                        scratchCard2.IsScratched = false;

                        _context.ScratchCard.Add(scratchCard2);
                        await _context.SaveChangesAsync();
                    }

                }
                return CreatedAtAction("GetScratchCard", scratchCard);

            }
            catch
            {
                throw;
            }

        }

        // DELETE: api/ScratchCards/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteScratchCard(Guid id)
        {
            var scratchCard = await _context.ScratchCard.FindAsync(id);
            if (scratchCard == null)
            {
                return NotFound();
            }

            _context.ScratchCard.Remove(scratchCard);
            await _context.SaveChangesAsync();

            return NoContent();
        }

		private bool ScratchCardExists(Guid id)
        {
            return _context.ScratchCard.Any(e => e.Id == id);
        }
    }
}
